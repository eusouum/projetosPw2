package projeto02;

public class Cat extends Animal {
    
    public void mia(){
        System.out.println("MIAU MIAU MIAUUU");
    }
    
    @Override
    public void caminha(){
        System.out.println("O gateneo está caminhando!!");
    }
    
}