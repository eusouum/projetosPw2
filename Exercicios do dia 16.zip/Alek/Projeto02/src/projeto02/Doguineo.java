package projeto02;

public class Doguineo extends Animal {
    
    public void late(){
        System.out.println("AU AU AU AU AU");
    }
    
    @Override
    public void caminha(){
        System.out.println("O Doguineo está caminhando!!");
    }
    
}