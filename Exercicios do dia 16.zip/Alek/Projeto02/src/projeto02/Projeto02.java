package projeto02;

public class Projeto02 {

    public static void main(String[] args) {
        
        Doguineo lagosta = new Doguineo();
        Cat tommy = new Cat();
        
        lagosta.late();
        tommy.mia();
        
        lagosta.caminha();
        tommy.caminha();
        
    }
    
}
