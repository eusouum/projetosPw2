package projeto03;

public class Miseravel extends Pessia {
    
    public void mendiga(){
        System.out.println("Boa Tarde, eu poderia estar matando...");
    }
    
}
