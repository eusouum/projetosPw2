package projeto03;

public class Pobre extends Pessia{
    
    public void trabalha(){
        
        System.out.println("Eu sou João e ainda não recebi meu Auxilio Emergencial");
    
    }
    
}
