package projeto04;

public class Ingresso {
    
    public double valor = 250;
    
    public void mostraInfo(){
        
        System.out.println("Informações da compra:"
                + "\n\nValor: R$" + this.valor);
    
    }
    
    
}